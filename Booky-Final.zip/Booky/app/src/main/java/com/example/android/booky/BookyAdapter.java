package com.example.android.booky;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 02/10/2016.
 */
public class BookyAdapter extends ArrayAdapter {
    public BookyAdapter(Context context, ArrayList<BookyItems> bookyArrrayList) {
        super(context, 0, bookyArrrayList);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rootView = convertView;
        if (rootView == null) {
            rootView = LayoutInflater.from(getContext()).inflate(R.layout.booky_item, parent, false);
        }

        final BookyItems bookyObject = (BookyItems) getItem(position);
        TextView title = (TextView) rootView.findViewById(R.id.title_booky);
        title.setText(bookyObject.getTitle());
        TextView author = (TextView) rootView.findViewById(R.id.author_booky);
        author.setText(bookyObject.getAuthor());
        RatingBar ratingBooky = (RatingBar) rootView.findViewById(R.id.ratingBar_booky);
        ratingBooky.setRating((float) bookyObject.getRating());
        TextView preview = (TextView) rootView.findViewById(R.id.preview);
        preview.setText("preview");
        preview.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Uri earthquackuri = Uri.parse(bookyObject.getUrl());
                Intent intent = new Intent(Intent.ACTION_VIEW, earthquackuri);
                getContext().startActivity(intent);
            }
        });


        TextView buy = (TextView) rootView.findViewById(R.id.buy);
        buy.setText("buy");
        buy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Uri earthquackuri = Uri.parse(bookyObject.getBuyUrl());
                Intent intent = new Intent(Intent.ACTION_VIEW, earthquackuri);
                getContext().startActivity(intent);
            }
        });

        return rootView;
    }
}
