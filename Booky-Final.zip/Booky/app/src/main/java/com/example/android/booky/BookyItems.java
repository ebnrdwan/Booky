package com.example.android.booky;

/**
 * Created by Abdulrhman on 02/10/2016.
 */
public class BookyItems {

    private String url;
    private String BuyUrl;
    private String title;
    private String author;
    private double rating;
    private String image;


    public String getBuyUrl() {
        return BuyUrl;
    }

    public void setBuyUrl(String buyUrl) {
        BuyUrl = buyUrl;
    }

    public BookyItems(String url, String buyUrl, String title, String author, double rating, String image) {
        this.url = url;
        BuyUrl = buyUrl;
        this.title = title;
        this.author = author;
        this.rating = rating;
        this.image = image;
    }



    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
