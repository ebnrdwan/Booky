package com.example.android.booky;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 02/10/2016.
 */
public class BookyAdapter extends ArrayAdapter {
    public BookyAdapter(Context context, int resource, ArrayList<BookyItems> bookyArrrayList) {
        super(context, 0, bookyArrrayList);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View rootView = convertView;
        if (rootView == null) {
            rootView = LayoutInflater.from(getContext()).inflate(R.layout.booky_item, parent, false);
        }

        BookyItems bookyObject = (BookyItems) getItem(position);


        ImageView imageBooky = (ImageView) rootView.findViewById(R.id.image_booky);
        imageBooky.setImageURI(Uri.parse(bookyObject.getImage()));

        TextView title = (TextView) rootView.findViewById(R.id.title_booky);
        title.setText(bookyObject.getTitle());

        TextView author = (TextView) rootView.findViewById(R.id.author_booky);
        author.setText(bookyObject.getAuthor());

        RatingBar ratingBooky = (RatingBar) rootView.findViewById(R.id.ratingBar_booky);
        ratingBooky.setRating((float) bookyObject.getRating());

        TextView preview = (TextView) rootView.findViewById(R.id.preview);
        preview.setText(bookyObject.getUrl());
        TextView buy = (TextView) rootView.findViewById(R.id.buy);
        buy.setText(bookyObject.getBuyUrl());

        return rootView;

    }
}
