package com.example.android.booky;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static final String LOG_TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);

        MenuItem searchItem = menu.findItem(R.id.search);
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                search=query;

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        return true;
    }

    private static  String search ;
    private  static String BOOKY_REQUEST = " https://www.googleapis.com/books/v1/volumes?q="+search +"maxResults=1";

    private class bookyAsync extends AsyncTask<URL, Void, ArrayList<BookyItems>> {
        @Override
        protected ArrayList<BookyItems> doInBackground(URL... params) {
            // Create URL object
            URL url = createUrl(BOOKY_REQUEST);

            // Perform HTTP request to the URL and receive a JSON response back
            String jsonResponse = "";
            try {
                jsonResponse = makeHttpRequest(url);
            } catch (IOException e) {
                // TODO Handle the IOException
                Log.d("HTTP Request Error","can't complete http request");
            }

            // Extract relevant fields from the JSON response and create an {@link Event} object
            ArrayList<BookyItems> BookyArrayList = extractBookyList(BOOKY_REQUEST);

            // Return the {@link Event} object as the result fo the {@link TsunamiAsyncTask}

            return BookyArrayList;

        }

        @Override
        protected void onPostExecute(ArrayList<BookyItems> bookyItemses) {
            ArrayList<BookyItems> BookyArrayList = extractBookyList(BOOKY_REQUEST);

            // Find a reference to the {@link ListView} in the layout
            ListView BookyListView = (ListView) findViewById(R.id.bookyList);

            // Create a new {@link ArrayAdapter} of earthquakes
            BookyAdapter adapter = new BookyAdapter(MainActivity.this,R.layout.activity_main,BookyArrayList);
            BookyListView.setAdapter(adapter);
        }

        private URL createUrl(String stringUrl) {
            URL url = null;
            try {
                url = new URL(stringUrl);
            } catch (MalformedURLException exception) {
                Log.e(LOG_TAG, "Error with creating URL", exception);
                return null;
            }
            return url;
        }
        private String makeHttpRequest(URL url) throws IOException {
            String jsonResponse = "";
            HttpURLConnection urlConnection = null;
            InputStream inputStream = null;
            try {
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setReadTimeout(10000 /* milliseconds */);
                urlConnection.setConnectTimeout(15000 /* milliseconds */);
                urlConnection.connect();
                if (urlConnection.getResponseCode()==200){
                    inputStream = urlConnection.getInputStream();
                    jsonResponse = readFromStream(inputStream);

                }

            } catch (IOException e) {
                // TODO: Handle the exception
                Log.e(LOG_TAG,"I/O Exception happend "+urlConnection.getResponseCode());
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
                if (inputStream != null) {
                    // function must handle java.io.IOException here
                    inputStream.close();
                }
            }
            return jsonResponse;
        }

        private String readFromStream(InputStream inputStream) throws IOException {
            StringBuilder output = new StringBuilder();
            if (inputStream != null) {
                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
                BufferedReader reader = new BufferedReader(inputStreamReader);
                String line = reader.readLine();
                while (line != null) {
                    output.append(line);
                    line = reader.readLine();
                }
            }
            return output.toString();
        }






        }
        public ArrayList<BookyItems> extractBookyList(String JSONObject){

            if (TextUtils.isEmpty(JSONObject)){
                return null;
            }


            ArrayList<BookyItems> mybookyArrayList=new ArrayList<>();
            try {

                JSONObject rootJSON= new JSONObject(BOOKY_REQUEST);
                JSONArray itemsJSONArray= rootJSON.getJSONArray("items");
                for (int i =0 ; i<itemsJSONArray.length(); i++){
                    JSONObject itemsJSONObject = itemsJSONArray.getJSONObject(i);
                    JSONObject volumeJSONObject = itemsJSONObject.getJSONObject("volumeInfo");
                    JSONArray AuthorJSONArray = volumeJSONObject.getJSONArray("authors");
                    String author = AuthorJSONArray.getString(0);
                    String title = volumeJSONObject.getString("title");
                    double averageRating = volumeJSONObject.getDouble("averageRating");
                    String previewLink = volumeJSONObject.getString("previewLink");
                    String infoLink = volumeJSONObject.getString("infoLink");
                    JSONObject imageJSONObject= volumeJSONObject.getJSONObject("imageLinks");
                    String image = imageJSONObject.getString("thumbnail");

                    BookyItems bookyItemsObject = new BookyItems(previewLink,infoLink,title,author,averageRating,image);
                    mybookyArrayList.add(bookyItemsObject);

                }




            } catch (JSONException e) {
             Log.e(LOG_TAG,"the error is "+e);
            }

            return mybookyArrayList;
        }

    }




