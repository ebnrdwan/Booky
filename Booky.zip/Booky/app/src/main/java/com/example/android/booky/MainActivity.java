package com.example.android.booky;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private StringBuilder myquery = new StringBuilder();
    private String search = "android";

    //
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_search, menu);

        MenuItem searchItem = menu.findItem(R.id.menu_search);
        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchItem);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                myquery.append(searchView.getQuery().toString().trim());
                search = searchView.getQuery().toString().trim();
                Log.e("hi search", "the final Result of the  search issssssssss " + search);
                Log.e("hi search", "the final Result of the   myQuery issssssssss " + myquery);
                Toast.makeText(MainActivity.this,search,Toast.LENGTH_SHORT).show();

                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                Log.e("hi search", "the current Text of the search is " + search);
                return false;
            }
        });

        return true;
    }

    public static final String LOG_TAG = MainActivity.class.getSimpleName();
    // // TODO: 05/10/2016 maybe a can use it by this way
    private String BOOKY_REQUEST = " https://www.googleapis.com/books/v1/volumes?q=" +search+ "&maxResults=30";

    //// TODO: 05/10/2016 maybe i can use it with this way instead of the previous
//    private String BOOKY_REQUEST = " https://www.googleapis.com/books/v1/volumes?q=" +myquery+ "&maxResults=30";


    private BookyAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bookyAsync task = new bookyAsync();
        task.execute(BOOKY_REQUEST);
        ListView BookyListView = (ListView) findViewById(R.id.bookyList);
        adapter = new BookyAdapter(this, new ArrayList<BookyItems>());
        BookyListView.setAdapter(adapter);
    }

    private URL createUrl(String stringUrl) {
        URL url = null;
        try {
            url = new URL(stringUrl);
        } catch (MalformedURLException exception) {
            Log.e(LOG_TAG, "Error with creating URL", exception);
            return null;
        }
        return url;
    }

    private String makeHttpRequest(URL url) throws IOException {
        String jsonResponse = "";
        HttpURLConnection urlConnection = null;
        InputStream inputStream = null;
        try {
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.setRequestMethod("GET");
            urlConnection.setReadTimeout(10000 /* milliseconds */);
            urlConnection.setConnectTimeout(15000 /* milliseconds */);
            urlConnection.connect();
            if (urlConnection.getResponseCode() == 200) {
                inputStream = urlConnection.getInputStream();
                jsonResponse = readFromStream(inputStream);
            }

        } catch (IOException e) {
            // TODO: Handle the exception
            Log.e(LOG_TAG, "I/O Exception happend " + urlConnection.getResponseCode());
        } finally {
            if (urlConnection != null) {
                urlConnection.disconnect();
            }
            if (inputStream != null) {

                inputStream.close();
            }
        }
        return jsonResponse;
    }

    @NonNull
    private String readFromStream(InputStream inputStream) throws IOException {
        StringBuilder output = new StringBuilder();
        if (inputStream != null) {
            InputStreamReader inputStreamReader = new InputStreamReader(inputStream, Charset.forName("UTF-8"));
            BufferedReader reader = new BufferedReader(inputStreamReader);
            String line = reader.readLine();
            while (line != null) {
                output.append(line);
                line = reader.readLine();
            }
        }
        return output.toString();
    }


    public ArrayList<BookyItems> extractBookyList(String JSONObject) {

        if (TextUtils.isEmpty(JSONObject)) {
            return null;
        }
        ArrayList<BookyItems> mybookyArrayList = new ArrayList<>();
        try {

            JSONObject rootJSON = new JSONObject(JSONObject);
            JSONArray itemsJSONArray = rootJSON.getJSONArray("items");
            for (int i = 0; i < itemsJSONArray.length(); i++) {
                JSONObject itemsJSONObject = itemsJSONArray.getJSONObject(i);
                JSONObject volumeJSONObject = itemsJSONObject.getJSONObject("volumeInfo");
                StringBuilder authorbuilder = new StringBuilder();

                if (volumeJSONObject.has("authors")) {
                    JSONArray AuthorJSONArray = volumeJSONObject.getJSONArray("authors");
                    authorbuilder.append(AuthorJSONArray.getString(0)).toString();
                }
                String author = authorbuilder.toString();
                String title = volumeJSONObject.getString("title");

                double averageRating = 0;
                if (volumeJSONObject.has("averageRating")) {
                    averageRating = volumeJSONObject.getDouble("averageRating");
                }
                String previewLink = volumeJSONObject.getString("previewLink");
                String infoLink = volumeJSONObject.getString("infoLink");
                JSONObject imageJSONObject = volumeJSONObject.getJSONObject("imageLinks");
                String image = imageJSONObject.getString("thumbnail");
                mybookyArrayList.add(new BookyItems(previewLink, infoLink, title, author, averageRating, image));
            }
            return mybookyArrayList;
        } catch (JSONException e) {
            Log.e(LOG_TAG, "the error is in line 233 " + e);
        }
        return mybookyArrayList;
    }

    public List<BookyItems> fetchData(String RequestedUrl) {
        URL url = createUrl(RequestedUrl);
        String theResponse = null;
        try {
            theResponse = makeHttpRequest(url);
        } catch (IOException e) {
            Log.e("QeuryUtils-175", "fetchDataMethod Exception is :" + e);
        }
        List<BookyItems> bookyitemList = extractBookyList(theResponse);
        return bookyitemList;
    }


    private class bookyAsync extends AsyncTask<String, Void, List<BookyItems>> {

        @Override
        protected List<BookyItems> doInBackground(String... urls) {
//             Create URL object
            URL url = createUrl(BOOKY_REQUEST);
            // Perform HTTP request to the URL and receive a JSON response back
            String jsonResponse = "";
            try {
                jsonResponse = makeHttpRequest(url);
            } catch (IOException e) {
                // TODO Handle the IOException
                Log.d("HTTP Request Error", "can't complete http request");
            }
            // Extract relevant fields from the JSON response and create an {@link Event} object
            List<BookyItems> theResult = extractBookyList(jsonResponse);


            // Return the {@link Event} object as the result fo the {@link TsunamiAsyncTask}

            return theResult;
        }

        @Override
        protected void onPostExecute(List<BookyItems> bookyItemses) {
            adapter.clear();
            if (bookyItemses != null && !bookyItemses.isEmpty()) {
                adapter.addAll(bookyItemses);
            }
        }
    }
}




